# EasyCHAID
Web app for running CHAID algorithm for creating decidion trees based on a dataset. CHAID stands for CHi-squared Automatic Interaction Detection.
